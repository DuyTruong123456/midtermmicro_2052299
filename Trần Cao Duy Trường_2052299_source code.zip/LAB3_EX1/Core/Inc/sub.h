#include "main.h"
#include "button.h"
#include "leds.h"
int timeout10s=10;
void fsm_simple_button_run(){
	for(int i=0;i<3;i++)
	{
		switch(i){
		   case 0:
				  if(isButtonPressed(0)){
					  ledIdx=0;
				  	  display7SEG(0);
				  	  timeout10s=10;
				  }
				  break;
		   case 1:
				  if(isButtonPressed(1)){
					  ledIdx++;
				  	  display7SEG(ledIdx);

				  	  timeout10s=10;
				  }
				  break;
		   case 2:
			if(isButtonPressed(2)){
				ledIdx--;
				  display7SEG(ledIdx);

				  timeout10s=10;
			  }
			break;
		}

	}
}
void automode(){
	if(timeout10s<0){
		ledIdx--;
		if(ledIdx<0){
			ledIdx=0;
			return;
		}
		display7SEG(ledIdx);
	}
}
void init(){
	display7SEG(0);
}

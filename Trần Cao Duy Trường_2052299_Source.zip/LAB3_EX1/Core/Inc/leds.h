

#ifndef INC_LEDS_H_
#define INC_LEDS_H_
#include "main.h"
int pinArr[7]={
		OUT6_Pin,
		OUT5_Pin,
		OUT4_Pin,
		OUT3_Pin,
		OUT2_Pin,
		OUT1_Pin,
		OUT0_Pin
};
int signal[10]={
		0x0040,
		0x0079,
		0x0024,
		0x0030,
		0x0019,
		0x0012,
		0x0002,
		0x0078,
		0x0000,
		0x0010,
};
int ledIdx=0;
void changeNum(int idx){
	if(idx<0){
		ledIdx=9;
		idx=9;
	}
	if(idx>9){
		ledIdx=0;
		idx=0;
	}
	for(int i=0;i<7;i++){
		HAL_GPIO_WritePin(GPIOA,pinArr[i],(signal[idx]>>i)&1);
	}
	ledIdx=idx;
	if(idx<0){
		ledIdx=9;
		idx=9;
	}
	if(idx>9){
		ledIdx=0;
		idx=0;
	}
}
void display7SEG(int num){
	for(int i=0;i<7;i++){
		HAL_GPIO_WritePin(GPIOA,pinArr[i],GPIO_PIN_SET);
	}
	changeNum(num);

}
int ledPin=OUT7_Pin;
void blinkLed(){
	HAL_GPIO_TogglePin(GPIOA,ledPin);

}
#endif /* INC_LEDS_H_ */
